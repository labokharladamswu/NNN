<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="0" tilewidth="64" tileheight="64" tilecount="9" columns="3">
 <image source="../monsters/raccoon/idle/0.png" width="240" height="240"/>
</tileset>
